
import React, { useState, useEffect, createContext, useContext } from 'react';
import { AppState, Lead, Service, CaseStudy, BlogPost, Config } from './types';
import { INITIAL_SERVICES, INITIAL_CASE_STUDIES, INITIAL_POSTS, INITIAL_CONFIG } from './constants';

interface AppContextType extends AppState {
  addLead: (lead: Omit<Lead, 'id' | 'timestamp' | 'status'>) => void;
  updateConfig: (config: Config) => void;
  updateServices: (services: Service[]) => void;
  updateCaseStudies: (cases: CaseStudy[]) => void;
  updatePosts: (posts: BlogPost[]) => void;
  updateLeadStatus: (id: string, status: Lead['status']) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};

// Fixed: Replaced React.FC with a standard function signature and optional children to resolve TypeScript errors
export const AppProvider = ({ children }: { children?: React.ReactNode }) => {
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('r07_state');
    if (saved) return JSON.parse(saved);
    return {
      services: INITIAL_SERVICES,
      caseStudies: INITIAL_CASE_STUDIES,
      leads: [],
      posts: INITIAL_POSTS,
      config: INITIAL_CONFIG,
    };
  });

  useEffect(() => {
    localStorage.setItem('r07_state', JSON.stringify(state));
  }, [state]);

  const addLead = (leadData: Omit<Lead, 'id' | 'timestamp' | 'status'>) => {
    const newLead: Lead = {
      ...leadData,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      status: 'new',
    };
    setState(prev => ({ ...prev, leads: [newLead, ...prev.leads] }));
  };

  const updateConfig = (config: Config) => setState(prev => ({ ...prev, config }));
  const updateServices = (services: Service[]) => setState(prev => ({ ...prev, services }));
  const updateCaseStudies = (caseStudies: CaseStudy[]) => setState(prev => ({ ...prev, caseStudies }));
  const updatePosts = (posts: BlogPost[]) => setState(prev => ({ ...prev, posts }));
  const updateLeadStatus = (id: string, status: Lead['status']) => {
    setState(prev => ({
      ...prev,
      leads: prev.leads.map(l => l.id === id ? { ...l, status } : l)
    }));
  };

  return (
    <AppContext.Provider value={{ ...state, addLead, updateConfig, updateServices, updateCaseStudies, updatePosts, updateLeadStatus }}>
      {children}
    </AppContext.Provider>
  );
};
