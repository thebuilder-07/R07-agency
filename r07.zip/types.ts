
export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  category: string;
  description: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  results: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  company: string;
  service: string;
  message: string;
  status: 'new' | 'contacted' | 'booked';
  timestamp: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
}

export interface Config {
  siteName: string;
  tagline: string;
  primaryColor: string;
  seoTitle: string;
  seoDescription: string;
}

export interface AppState {
  services: Service[];
  caseStudies: CaseStudy[];
  leads: Lead[];
  posts: BlogPost[];
  config: Config;
}
