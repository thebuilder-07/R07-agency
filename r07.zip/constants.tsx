
import { Service, CaseStudy, BlogPost, Config } from './types';

export const INITIAL_SERVICES: Service[] = [
  {
    id: '1',
    title: 'Premium Thumbnail Creation',
    description: 'Stop the scroll with high-CTR thumbnails. We design visuals that demand clicks and drive massive engagement for your channel.',
    icon: '🖼️'
  },
  {
    id: '2',
    title: 'Expert Video Editing',
    description: 'From dynamic short-form to cinematic long-form. Our editing process ensures high retention and a premium look for your brand.',
    icon: '🎬'
  },
  {
    id: '3',
    title: 'Web Design & Development',
    description: 'High-performance website building services for every industry. We build conversion-optimized digital homes tailored to your business goals.',
    icon: '🌐'
  }
];

export const INITIAL_CASE_STUDIES: CaseStudy[] = [
  {
    id: 'eggs-project',
    title: 'Eggs Brand Platform',
    category: 'Web Architecture',
    description: 'A minimalist, high-converting e-commerce and brand showcase for a premium lifestyle label.',
    mediaUrl: 'https://images.unsplash.com/photo-1481349518771-20055b2a7b24?q=80&w=2000&auto=format&fit=crop',
    mediaType: 'image',
    results: 'Sub-second load times & 22% conversion lift'
  },
  {
    id: '1',
    title: 'The Nitro Launch',
    category: 'Video Marketing',
    description: 'A 30-day viral campaign for a sustainable energy brand.',
    mediaUrl: 'https://picsum.photos/seed/nitro/800/600',
    mediaType: 'image',
    results: '2.5M views, +45% in direct sales'
  },
  {
    id: '2',
    title: 'Zenith Tech Refresh',
    category: 'Web Design',
    description: 'Full digital transformation for a Series B SaaS company.',
    mediaUrl: 'https://picsum.photos/seed/zenith/800/600',
    mediaType: 'image',
    results: '300% increase in demo bookings'
  }
];

export const INITIAL_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'The Future of Video in 2025',
    excerpt: 'How AI and short-form content are reshaping the marketing landscape.',
    content: 'Long form content is evolving...',
    date: '2024-05-20',
    author: 'Revanth'
  }
];

export const INITIAL_CONFIG: Config = {
  siteName: 'R07',
  tagline: 'High-Performance Visuals and Digital Architecture.',
  primaryColor: '#ff3d00',
  seoTitle: 'R07 | Thumbnails, Video Editing & Web Development',
  seoDescription: 'Premium agency specializing in high-click thumbnails, professional video editing, and industry-leading web development.'
};
