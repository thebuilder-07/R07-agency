
import React from 'react';
import { HashRouter, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './AppContext';
import LandingPage from './pages/LandingPage';
import AdminDashboard from './pages/AdminDashboard';
import AdminLogin from './pages/AdminLogin';
import BlogPage from './pages/BlogPage';

// Fixed: Made children optional to resolve Property 'children' is missing error
const ProtectedRoute = ({ children }: { children?: React.ReactNode }) => {
  const isAuth = localStorage.getItem('r07_admin_auth') === 'true';
  return isAuth ? <>{children}</> : <Navigate to="/admin/login" />;
};

const Navbar = () => {
  const { config } = useApp();
  const location = useLocation();
  const isAdmin = location.pathname.startsWith('/admin') && location.pathname !== '/admin/login';
  const isLoginPage = location.pathname === '/admin/login';

  if (isLoginPage) return null;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4 flex justify-between items-center glass border-b border-white/5">
      <Link to="/" className="text-2xl font-black tracking-tighter text-white">
        {config.siteName}<span className="text-[#ff3d00]">.</span>
      </Link>
      <div className="hidden md:flex gap-8 text-sm font-semibold uppercase tracking-widest text-white/70">
        <Link to="/" className="hover:text-white transition-colors">Home</Link>
        <Link to="/#services" className="hover:text-white transition-colors">Services</Link>
        <Link to="/#work" className="hover:text-white transition-colors">Work</Link>
        <Link to="/blog" className="hover:text-white transition-colors">Insights</Link>
      </div>
      <div className="flex gap-4">
        <Link to={isAdmin ? "/" : "/admin/login"} className="px-4 py-2 text-xs font-bold border border-white/10 rounded-full hover:bg-white/5 transition-all">
          {isAdmin ? 'View Site' : 'Admin'}
        </Link>
        <Link to="/#book" className="px-6 py-2 bg-gradient text-white text-xs font-bold rounded-full hover:scale-105 transition-all">
          Book Now
        </Link>
      </div>
    </nav>
  );
};

const Footer = () => {
  const { config } = useApp();
  const location = useLocation();
  if (location.pathname.startsWith('/admin')) return null;

  return (
    <footer className="bg-black py-20 border-t border-white/5 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-2">
          <h2 className="text-3xl font-black mb-6">{config.siteName}<span className="text-[#ff3d00]">.</span></h2>
          <p className="text-white/40 max-w-sm">{config.seoDescription}</p>
        </div>
        <div>
          <h4 className="font-bold mb-6 text-white/80">Navigation</h4>
          <ul className="space-y-4 text-white/40 text-sm">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/blog">Blog</Link></li>
            <li><Link to="/#work">Case Studies</Link></li>
            <li><Link to="/#book">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-6 text-white/80">Socials</h4>
          <ul className="space-y-4 text-white/40 text-sm">
            <li><a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff3d00]">LinkedIn</a></li>
            <li><a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff3d00]">Instagram</a></li>
            <li><a href="https://x.com/R07_edits" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff3d00]">Twitter / X (@R07_edits)</a></li>
            <li><a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#ff3d00]">YouTube</a></li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between text-xs text-white/20">
        <p>&copy; {new Date().getFullYear()} {config.siteName} Agency. All rights reserved.</p>
        <p>Built for Performance.</p>
      </div>
    </footer>
  );
};

// Fixed: Removed React.FC to prevent children-related type errors when usage lacks children
const App = () => {
  return (
    <AppProvider>
      <HashRouter>
        <div className="min-h-screen">
          <Navbar />
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin/*" element={
              <ProtectedRoute>
                <AdminDashboard />
              </ProtectedRoute>
            } />
            <Route path="/blog" element={<BlogPage />} />
          </Routes>
          <Footer />
        </div>
      </HashRouter>
    </AppProvider>
  );
};

export default App;
