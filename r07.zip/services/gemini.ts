
import { GoogleGenAI } from "@google/genai";

// Always initialize GoogleGenAI inside the function to use the most up-to-date API_KEY from the environment
export const generateContent = async (prompt: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    // Access response text directly via the .text property
    return response.text || "No response generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating content. Please try again.";
  }
};
