
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useApp } from '../AppContext';

const LandingPage = () => {
  const { config, services, caseStudies, addLead } = useApp();
  const location = useLocation();
  const [formData, setFormData] = useState({ name: '', email: '', company: '', service: services[0]?.title || '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  // Handle scrolling to hash sections
  useEffect(() => {
    if (location.hash) {
      const id = location.hash.substring(1);
      const element = document.getElementById(id);
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [location.pathname, location.hash]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Save locally for Admin Dashboard
    addLead(formData);

    // Prepare WhatsApp Message
    const waNumber = "917075466515";
    const encodedMessage = `🔥 *New Inquiry for R07 Agency* 🔥%0A%0A*Name:* ${encodeURIComponent(formData.name)}%0A*Email:* ${encodeURIComponent(formData.email)}%0A*Company:* ${encodeURIComponent(formData.company)}%0A*Service:* ${encodeURIComponent(formData.service)}%0A*Message:* ${encodeURIComponent(formData.message)}`;
    const waUrl = `https://wa.me/${waNumber}?text=${encodedMessage}`;

    setSubmitted(true);
    setFormData({ name: '', email: '', company: '', service: services[0]?.title || '', message: '' });
    
    // Open WhatsApp in a new tab
    window.open(waUrl, '_blank');
  };

  return (
    <main className="overflow-hidden">
      {/* Hero Section */}
      <section id="top" className="relative h-screen flex items-center justify-center px-6 overflow-hidden bg-black">
        <div className="absolute inset-0 z-0 opacity-20 bg-[url('https://picsum.photos/seed/video/1920/1080')] bg-cover bg-center"></div>
        <div className="absolute inset-0 z-0 bg-gradient-to-b from-black/60 via-black/80 to-black"></div>
        
        <div className="relative z-10 max-w-5xl text-center space-y-8 animate-in fade-in slide-in-from-bottom-12 duration-1000">
          <h1 className="text-6xl md:text-8xl font-black leading-none tracking-tighter">
            {config.tagline.split(' ').map((word, i) => (
              <span key={i} className={i === 2 || i === 3 ? "text-gradient" : ""}>{word} </span>
            ))}
          </h1>
          <p className="text-xl md:text-2xl text-white/60 font-light max-w-3xl mx-auto">
            High-click thumbnails, retention-focused video editing, and elite web architecture for every industry.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <a href="#book" onClick={(e) => { e.preventDefault(); document.getElementById('book')?.scrollIntoView({ behavior: 'smooth' }); }} className="px-10 py-5 bg-gradient text-white font-bold rounded-full text-lg hover:scale-105 transition-all shadow-xl shadow-orange-600/20">
              Launch Your Project
            </a>
            <a href="#work" onClick={(e) => { e.preventDefault(); document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' }); }} className="px-10 py-5 border border-white/20 text-white font-bold rounded-full text-lg hover:bg-white/5 transition-all">
              See Our Portfolio
            </a>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-32 px-6 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end gap-8 mb-20">
            <div>
              <span className="text-[#ff3d00] font-bold tracking-widest uppercase text-sm mb-4 block">Our Expertise</span>
              <h2 className="text-5xl font-black">Conversion-Driven Services.</h2>
            </div>
            <p className="text-white/40 max-w-md mb-2">We focus on the metrics that matter: Click-Through Rate, Retention, and Conversion Rate.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service) => (
              <div key={service.id} className="group p-10 bg-white/5 border border-white/5 rounded-3xl hover:border-white/20 transition-all hover:translate-y-[-8px]">
                <div className="text-5xl mb-8 group-hover:scale-110 transition-transform inline-block">{service.icon}</div>
                <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
                <p className="text-white/60 leading-relaxed mb-6">{service.description}</p>
                <div className="w-12 h-1 bg-white/10 group-hover:bg-[#ff3d00] transition-colors group-hover:w-full"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Results Section */}
      <section id="work" className="py-32 px-6 bg-black relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl font-black mb-4">Our Work.</h2>
            <p className="text-white/40">Premium samples of high-performance content and architecture.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {caseStudies.map((study) => (
              <div key={study.id} className="group relative overflow-hidden rounded-3xl cursor-pointer">
                {study.mediaType === 'video' ? (
                  <video 
                    src={study.mediaUrl} 
                    autoPlay 
                    loop 
                    muted 
                    playsInline 
                    className="w-full h-[500px] object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                ) : (
                  <img src={study.mediaUrl} alt={study.title} className="w-full h-[500px] object-cover group-hover:scale-105 transition-transform duration-700" />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
                <div className="absolute bottom-0 p-10 w-full">
                  <span className="px-4 py-1 bg-[#ff3d00] text-xs font-bold rounded-full uppercase mb-4 inline-block">{study.category}</span>
                  <h3 className="text-3xl font-bold mb-2">{study.title}</h3>
                  <p className="text-white/60 mb-6">{study.description}</p>
                  <div className="flex items-center gap-4 py-4 px-6 bg-white/10 backdrop-blur-md rounded-2xl border border-white/10">
                    <span className="text-[#ff3d00] font-black text-lg">Results:</span>
                    <span className="font-semibold text-white/90">{study.results}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How We Work Section */}
      <section className="py-32 px-6 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-20 items-center">
          <div className="lg:w-1/2">
            <span className="text-[#ff3d00] font-bold tracking-widest uppercase text-sm mb-4 block">Process</span>
            <h2 className="text-5xl font-black mb-10">Scale Faster with R07.</h2>
            <div className="space-y-12">
              <div className="flex gap-8">
                <div className="flex-shrink-0 w-12 h-12 bg-white/5 flex items-center justify-center rounded-full font-black text-[#ff3d00] border border-white/10">01</div>
                <div>
                  <h4 className="text-xl font-bold mb-2">Strategic Content Audit</h4>
                  <p className="text-white/40">We analyze your current channel or site metrics to find areas for immediate conversion improvement.</p>
                </div>
              </div>
              <div className="flex gap-8">
                <div className="flex-shrink-0 w-12 h-12 bg-white/5 flex items-center justify-center rounded-full font-black text-[#ff3d00] border border-white/10">02</div>
                <div>
                  <h4 className="text-xl font-bold mb-2">High-Performance Production</h4>
                  <p className="text-white/40">Our designers and editors execute on assets designed to dominate the algorithm and the market.</p>
                </div>
              </div>
              <div className="flex gap-8">
                <div className="flex-shrink-0 w-12 h-12 bg-white/5 flex items-center justify-center rounded-full font-black text-[#ff3d00] border border-white/10">03</div>
                <div>
                  <h4 className="text-xl font-bold mb-2">Industry-Agnostic Scaling</h4>
                  <p className="text-white/40">Whether you're in SaaS, Crypto, or Lifestyle, our web and video solutions are built to scale your specific niche.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:w-1/2 relative">
             <img src="https://picsum.photos/seed/agency/800/1000" alt="Process" className="rounded-3xl grayscale hover:grayscale-0 transition-all duration-1000" />
             <div className="absolute -bottom-10 -left-10 p-10 glass border border-white/10 rounded-3xl hidden md:block">
               <div className="text-4xl font-black text-[#ff3d00]">85%+</div>
               <div className="text-white/60 font-medium">Avg. Retention Boost</div>
             </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 px-6 bg-black">
        <div className="max-w-4xl mx-auto text-center italic">
          <div className="text-6xl text-[#ff3d00] mb-8 font-serif">"</div>
          <p className="text-3xl md:text-4xl font-light text-white/80 leading-snug mb-10">
            R07 didn't just rebuild our site; they turned it into a conversion machine. Their thumbnails literally tripled our channel's CTR in less than a month.
          </p>
          <div className="flex items-center justify-center gap-4">
            <img src="https://picsum.photos/seed/founder/100/100" className="w-16 h-16 rounded-full border-2 border-[#ff3d00]" />
            <div className="text-left">
              <div className="font-bold text-lg">Revanth</div>
              <div className="text-[#ff3d00] text-sm uppercase tracking-widest font-black">Founder, R07 Agency</div>
            </div>
          </div>
        </div>
      </section>

      {/* Booking / Contact Form */}
      <section id="book" className="py-32 px-6 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto bg-black rounded-[4rem] border border-white/5 p-12 md:p-24 flex flex-col md:flex-row gap-20">
          <div className="md:w-1/2">
            <h2 className="text-6xl font-black mb-8">Ready to Dominate?</h2>
            <p className="text-white/40 text-lg mb-12">Stop settling for mediocre assets. Book a call today and let's build the visual engine your brand deserves.</p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">📍</div>
                <span>India | Global Performance Hub</span>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">📧</div>
                <span>orvexarise@gmail.com</span>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">💬</div>
                <span>WhatsApp: +91 7075466515</span>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">𝕏</div>
                <a href="https://x.com/R07_edits" target="_blank" rel="noopener noreferrer" className="text-[#ff3d00] font-bold hover:underline">X: @R07_edits</a>
              </div>
            </div>
          </div>

          <div className="md:w-1/2">
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-6 animate-in zoom-in duration-500">
                <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center text-5xl">✓</div>
                <h3 className="text-3xl font-black">Success.</h3>
                <p className="text-white/40">You are being redirected to WhatsApp to confirm your booking.</p>
                <button onClick={() => setSubmitted(false)} className="text-[#ff3d00] font-bold">Send another message</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <input 
                    required 
                    type="text" 
                    placeholder="Full Name" 
                    className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:outline-none focus:border-[#ff3d00] transition-colors" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                  <input 
                    required 
                    type="email" 
                    placeholder="Work Email" 
                    className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:outline-none focus:border-[#ff3d00] transition-colors" 
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <input 
                    type="text" 
                    placeholder="Company" 
                    className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:outline-none focus:border-[#ff3d00] transition-colors" 
                    value={formData.company}
                    onChange={(e) => setFormData({...formData, company: e.target.value})}
                  />
                  <select 
                    className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:outline-none focus:border-[#ff3d00] transition-colors"
                    value={formData.service}
                    onChange={(e) => setFormData({...formData, service: e.target.value})}
                  >
                    {services.map(s => <option key={s.id} value={s.title}>{s.title}</option>)}
                  </select>
                </div>
                <textarea 
                  placeholder="Tell us about your project..." 
                  rows={4} 
                  className="w-full bg-white/5 border border-white/10 p-4 rounded-xl focus:outline-none focus:border-[#ff3d00] transition-colors"
                  value={formData.message}
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                ></textarea>
                <button type="submit" className="w-full py-5 bg-gradient text-white font-black text-xl rounded-xl hover:scale-[1.02] transition-all">
                  Book Strategy Session (via WhatsApp)
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-32 px-6 bg-black">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-black mb-12 text-center">Frequently Asked.</h2>
          <div className="space-y-4">
            {[
              { q: "Which industries do you build websites for?", a: "We build for every industry—from SaaS and FinTech to Real Estate and E-commerce. Every site is custom-built to convert." },
              { q: "What is the turnaround time for video editing?", a: "Short-form edits typically take 24-48 hours, while long-form high-production videos take 5-7 business days." },
              { q: "Do you offer thumbnail A/B testing?", a: "Yes, we often provide variations for you to test so we can double down on the highest performing concept." }
            ].map((item, i) => (
              <details key={i} className="group glass border border-white/5 rounded-2xl">
                <summary className="p-6 cursor-pointer font-bold flex justify-between items-center list-none">
                  {item.q}
                  <span className="text-[#ff3d00] group-open:rotate-45 transition-transform">+</span>
                </summary>
                <div className="px-6 pb-6 text-white/40">{item.a}</div>
              </details>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
};

export default LandingPage;
