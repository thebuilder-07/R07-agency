
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'r07' && password === 'Soumya76**') {
      localStorage.setItem('r07_admin_auth', 'true');
      navigate('/admin');
    } else {
      setError('Invalid architect credentials.');
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-6">
      <div className="absolute inset-0 z-0 opacity-10 bg-[url('https://picsum.photos/seed/security/1920/1080')] bg-cover bg-center"></div>
      <div className="relative z-10 w-full max-w-md p-10 glass border border-white/5 rounded-[3rem] shadow-2xl">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-black mb-2">R07 Admin<span className="text-[#ff3d00]">.</span></h2>
          <p className="text-white/40 text-sm font-bold uppercase tracking-widest">Architect Access Only</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-sm rounded-xl font-bold text-center animate-in fade-in zoom-in">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-[#ff3d00] tracking-widest px-1">Username</label>
            <input 
              required
              type="text" 
              className="w-full bg-white/5 border border-white/10 p-5 rounded-2xl focus:border-[#ff3d00] outline-none transition-all"
              placeholder="Architect Name"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black uppercase text-[#ff3d00] tracking-widest px-1">Password</label>
            <input 
              required
              type="password" 
              className="w-full bg-white/5 border border-white/10 p-5 rounded-2xl focus:border-[#ff3d00] outline-none transition-all"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button type="submit" className="w-full py-5 bg-gradient text-white font-black text-lg rounded-2xl hover:scale-[1.02] transition-all shadow-xl shadow-orange-600/20">
            Authorize Entry
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
