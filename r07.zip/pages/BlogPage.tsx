
import React from 'react';
import { useApp } from '../AppContext';

const BlogPage = () => {
  const { posts } = useApp();

  return (
    <main className="pt-32 pb-20 px-6 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-20">
          <h1 className="text-6xl font-black mb-6">Agency Insights<span className="text-[#ff3d00]">.</span></h1>
          <p className="text-white/40 text-xl max-w-2xl">Strategy, creative theory, and industry shifts that actually matter for your growth.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {posts.map((post) => (
            <article key={post.id} className="group cursor-pointer">
              <div className="aspect-video mb-6 overflow-hidden rounded-2xl bg-white/5">
                <img src={`https://picsum.photos/seed/${post.id}/800/600`} alt={post.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700" />
              </div>
              <div className="space-y-4">
                <div className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest text-white/40">
                  <span>{post.date}</span>
                  <span className="w-1 h-1 bg-[#ff3d00] rounded-full"></span>
                  <span>{post.author}</span>
                </div>
                <h2 className="text-2xl font-bold group-hover:text-[#ff3d00] transition-colors">{post.title}</h2>
                <p className="text-white/40 leading-relaxed line-clamp-3">{post.excerpt}</p>
                <button className="text-[#ff3d00] font-bold text-sm tracking-widest uppercase flex items-center gap-2">
                  Read More
                  <span className="group-hover:translate-x-2 transition-transform">→</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
};

export default BlogPage;
