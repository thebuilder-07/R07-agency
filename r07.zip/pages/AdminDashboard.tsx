
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../AppContext';
import { generateContent } from '../services/gemini';
import { CaseStudy } from '../types';

const AdminDashboard = () => {
  const { 
    leads, services, caseStudies, posts, config, 
    updateConfig, updateServices, updateCaseStudies, updatePosts, updateLeadStatus 
  } = useApp();
  
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'leads' | 'content' | 'seo' | 'cms' | 'portfolio'>('leads');
  const [aiGenerating, setAiGenerating] = useState(false);
  const [editingCase, setEditingCase] = useState<Partial<CaseStudy> | null>(null);

  const handleLogout = () => {
    localStorage.removeItem('r07_admin_auth');
    navigate('/admin/login');
  };

  const handleAiBlogDraft = async () => {
    setAiGenerating(true);
    const prompt = `Write a high-converting blog post headline and short excerpt for ${config.siteName} agency about thumbnail conversion and web architecture in 2025.`;
    const result = await generateContent(prompt);
    
    const newPost = {
      id: Math.random().toString(36).substr(2, 9),
      title: result.split('\n')[0].replace('Headline: ', ''),
      excerpt: result.split('\n').slice(1).join(' ').substring(0, 150) + '...',
      content: result,
      date: new Date().toISOString().split('T')[0],
      author: 'AI Assistant'
    };
    updatePosts([newPost, ...posts]);
    setAiGenerating(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingCase) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditingCase({
          ...editingCase,
          mediaUrl: reader.result as string,
          mediaType: file.type.startsWith('video') ? 'video' : 'image'
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const saveCaseStudy = () => {
    if (!editingCase) return;
    const newCase: CaseStudy = {
      id: editingCase.id || Math.random().toString(36).substr(2, 9),
      title: editingCase.title || 'Untitled',
      category: editingCase.category || 'General',
      description: editingCase.description || '',
      mediaUrl: editingCase.mediaUrl || '',
      mediaType: editingCase.mediaType || 'image',
      results: editingCase.results || ''
    };

    if (editingCase.id) {
      updateCaseStudies(caseStudies.map(c => c.id === editingCase.id ? newCase : c));
    } else {
      updateCaseStudies([newCase, ...caseStudies]);
    }
    setEditingCase(null);
  };

  return (
    <div className="pt-24 min-h-screen bg-[#050505]">
      <div className="max-w-[1600px] mx-auto p-6 flex flex-col lg:flex-row gap-10">
        
        {/* Sidebar Nav */}
        <aside className="lg:w-64 space-y-2">
          <div className="p-6 mb-4 text-center border-b border-white/5">
            <h1 className="text-xl font-black">{config.siteName} OS</h1>
            <p className="text-[9px] text-white/20 uppercase tracking-widest font-black mt-1">v2.5 High-Octane</p>
          </div>
          <button 
            onClick={() => setActiveTab('leads')}
            className={`w-full text-left px-6 py-4 rounded-xl font-bold transition-all flex items-center gap-4 ${activeTab === 'leads' ? 'bg-[#ff3d00] text-white shadow-lg shadow-[#ff3d00]/20' : 'text-white/40 hover:bg-white/5'}`}
          >
            📊 Pipeline
          </button>
          <button 
            onClick={() => setActiveTab('content')}
            className={`w-full text-left px-6 py-4 rounded-xl font-bold transition-all flex items-center gap-4 ${activeTab === 'content' ? 'bg-[#ff3d00] text-white shadow-lg shadow-[#ff3d00]/20' : 'text-white/40 hover:bg-white/5'}`}
          >
            🖌️ Brand Site
          </button>
          <button 
            onClick={() => setActiveTab('portfolio')}
            className={`w-full text-left px-6 py-4 rounded-xl font-bold transition-all flex items-center gap-4 ${activeTab === 'portfolio' ? 'bg-[#ff3d00] text-white shadow-lg shadow-[#ff3d00]/20' : 'text-white/40 hover:bg-white/5'}`}
          >
            🎬 Portfolio
          </button>
          <button 
            onClick={() => setActiveTab('cms')}
            className={`w-full text-left px-6 py-4 rounded-xl font-bold transition-all flex items-center gap-4 ${activeTab === 'cms' ? 'bg-[#ff3d00] text-white shadow-lg shadow-[#ff3d00]/20' : 'text-white/40 hover:bg-white/5'}`}
          >
            📝 Insights
          </button>
          <button 
            onClick={() => setActiveTab('seo')}
            className={`w-full text-left px-6 py-4 rounded-xl font-bold transition-all flex items-center gap-4 ${activeTab === 'seo' ? 'bg-[#ff3d00] text-white shadow-lg shadow-[#ff3d00]/20' : 'text-white/40 hover:bg-white/5'}`}
          >
            🔍 SEO
          </button>
          <div className="pt-10">
            <button 
              onClick={handleLogout}
              className="w-full text-left px-6 py-4 rounded-xl font-bold text-red-500 hover:bg-red-500/10 transition-all flex items-center gap-4 border border-red-500/20"
            >
              🚪 Logout
            </button>
          </div>
        </aside>

        {/* Main Panel */}
        <main className="flex-1 glass border border-white/5 rounded-[2.5rem] p-8 lg:p-12 min-h-[700px] shadow-2xl">
          
          {/* LEADS TAB */}
          {activeTab === 'leads' && (
            <div className="animate-in fade-in duration-500">
              <h2 className="text-3xl font-black mb-10 flex justify-between items-center">
                Inbound Pipeline
                <span className="text-xs font-normal text-white/40 tracking-widest uppercase">Total: {leads.length}</span>
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 text-white/40 text-[10px] font-black uppercase tracking-widest">
                      <th className="pb-4 px-2">Client / Company</th>
                      <th className="pb-4 px-2">Inquiry Type</th>
                      <th className="pb-4 px-2">Date</th>
                      <th className="pb-4 px-2">Status</th>
                      <th className="pb-4 px-2">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {leads.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-20 text-center text-white/20 font-bold italic tracking-wide">No inbound traffic yet. Build some hype.</td>
                      </tr>
                    ) : leads.map((lead) => (
                      <tr key={lead.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-6 px-2">
                          <div className="font-bold text-white">{lead.name}</div>
                          <div className="text-xs text-white/40">{lead.company} • {lead.email}</div>
                        </td>
                        <td className="py-6 px-2">
                          <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-black uppercase tracking-wider">{lead.service}</span>
                        </td>
                        <td className="py-6 px-2 text-xs text-white/40">{new Date(lead.timestamp).toLocaleDateString()}</td>
                        <td className="py-6 px-2">
                          <select 
                            value={lead.status}
                            onChange={(e) => updateLeadStatus(lead.id, e.target.value as any)}
                            className={`text-[10px] font-black uppercase px-3 py-1 rounded-full outline-none appearance-none cursor-pointer border border-white/5 ${
                              lead.status === 'new' ? 'bg-blue-500/20 text-blue-400' :
                              lead.status === 'contacted' ? 'bg-yellow-500/20 text-yellow-400' :
                              'bg-green-500/20 text-green-400'
                            }`}
                          >
                            <option value="new">New</option>
                            <option value="contacted">Contacted</option>
                            <option value="booked">Booked</option>
                          </select>
                        </td>
                        <td className="py-6 px-2">
                          <button onClick={() => alert(`Message: ${lead.message}`)} className="text-[#ff3d00] text-xs font-black uppercase tracking-tighter hover:underline">Detail</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* PORTFOLIO TAB */}
          {activeTab === 'portfolio' && (
            <div className="animate-in fade-in duration-500">
              <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black">Portfolio Management</h2>
                <div className="flex gap-4">
                  <button 
                    onClick={() => setEditingCase({})}
                    className="px-8 py-4 bg-[#ff3d00] text-white rounded-full text-xs font-black uppercase tracking-widest transition-all hover:scale-105 shadow-xl shadow-orange-600/20"
                  >
                    + Add New Piece
                  </button>
                </div>
              </div>

              {editingCase && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/95 backdrop-blur-md animate-in fade-in duration-300">
                  <div className="bg-[#0a0a0a] border border-white/10 p-10 rounded-[3rem] w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative">
                    <button 
                      onClick={() => setEditingCase(null)}
                      className="absolute top-8 right-8 w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/10"
                    >
                      ✕
                    </button>
                    <h3 className="text-3xl font-black mb-10">{editingCase.id ? 'Refine Project' : 'Construct New Project'}</h3>
                    <div className="space-y-10">
                      <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-3">
                          <label className="text-[10px] uppercase font-black text-[#ff3d00] tracking-widest px-1">Project Identifier</label>
                          <input 
                            type="text" 
                            placeholder="e.g. Eggs Website Redesign"
                            className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-bold"
                            value={editingCase.title || ''}
                            onChange={e => setEditingCase({...editingCase, title: e.target.value})}
                          />
                        </div>
                        <div className="space-y-3">
                          <label className="text-[10px] uppercase font-black text-[#ff3d00] tracking-widest px-1">Service category</label>
                          <select 
                            className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-bold"
                            value={editingCase.category || ''}
                            onChange={e => setEditingCase({...editingCase, category: e.target.value})}
                          >
                            <option value="">Choose Industry Sector</option>
                            <option value="Thumbnail Design">Thumbnail Design</option>
                            <option value="Video Editing">Video Editing</option>
                            <option value="Web Development">Web Development</option>
                            <option value="Web Architecture">Web Architecture</option>
                            <option value="Brand Strategy">Brand Strategy</option>
                          </select>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black text-[#ff3d00] tracking-widest px-1">Architectural Brief</label>
                        <textarea 
                          rows={3}
                          placeholder="Summarize the core objective and execution."
                          className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-medium leading-relaxed"
                          value={editingCase.description || ''}
                          onChange={e => setEditingCase({...editingCase, description: e.target.value})}
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black text-[#ff3d00] tracking-widest px-1">Performance Benchmarks (KPIs)</label>
                        <input 
                          type="text" 
                          className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-bold"
                          value={editingCase.results || ''}
                          onChange={e => setEditingCase({...editingCase, results: e.target.value})}
                          placeholder="e.g. 15% CTR Increase, 2M+ organic views"
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black text-[#ff3d00] tracking-widest px-1">Asset Ingestion (Photo/Video)</label>
                        <div className="flex flex-col gap-8">
                          <div className="relative group">
                            <input 
                              type="file" 
                              accept="image/*,video/*"
                              onChange={handleFileUpload}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                            />
                            <div className="w-full py-16 border-2 border-dashed border-white/5 rounded-[2rem] flex flex-col items-center justify-center gap-4 group-hover:border-[#ff3d00]/30 transition-all bg-white/2">
                              <span className="text-5xl">📁</span>
                              <div className="text-center">
                                <span className="block text-lg font-black group-hover:text-white transition-colors">Select Visual Asset</span>
                                <span className="text-[10px] text-white/20 uppercase tracking-widest font-black">MP4, PNG, JPG Accepted</span>
                              </div>
                            </div>
                          </div>
                          {editingCase.mediaUrl && (
                            <div className="mt-2 aspect-video relative rounded-[2rem] overflow-hidden border border-white/5 shadow-2xl">
                              {editingCase.mediaType === 'video' ? (
                                <video src={editingCase.mediaUrl} className="w-full h-full object-cover" controls autoPlay muted loop />
                              ) : (
                                <img src={editingCase.mediaUrl} className="w-full h-full object-cover" />
                              )}
                              <div className="absolute bottom-6 right-6 bg-black/80 backdrop-blur-md px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10">
                                {editingCase.mediaType} Feed Active
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-4 pt-4">
                        <button 
                          onClick={saveCaseStudy}
                          className="flex-1 py-6 bg-[#ff3d00] text-white font-black text-xl rounded-[1.5rem] shadow-xl shadow-orange-600/20 hover:scale-[1.02] transition-all"
                        >
                          Commit to Portfolio
                        </button>
                        <button 
                          onClick={() => setEditingCase(null)}
                          className="px-12 py-6 bg-white/5 border border-white/10 text-white font-black rounded-[1.5rem] hover:bg-white/10 transition-all uppercase tracking-widest text-xs"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                {caseStudies.map((study) => (
                  <div key={study.id} className="group p-8 bg-white/5 border border-white/5 rounded-[2.5rem] space-y-6 hover:border-[#ff3d00]/20 transition-all hover:bg-white/2">
                    <div className="aspect-video relative rounded-2xl overflow-hidden border border-white/5 shadow-xl">
                      {study.mediaType === 'video' ? (
                        <video src={study.mediaUrl} className="w-full h-full object-cover" muted loop autoPlay />
                      ) : (
                        <img src={study.mediaUrl} className="w-full h-full object-cover" />
                      )}
                      <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-sm px-4 py-1.5 rounded-full text-[9px] uppercase font-black tracking-widest border border-white/10">
                        {study.mediaType}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] font-black uppercase text-[#ff3d00] mb-2 tracking-widest">{study.category}</div>
                      <h4 className="font-black text-2xl mb-2 line-clamp-1">{study.title}</h4>
                      <div className="flex items-center gap-2 mb-6">
                        <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                        <p className="text-xs text-white/40 font-bold uppercase tracking-wider">{study.results}</p>
                      </div>
                      <div className="flex gap-4 pt-6 border-t border-white/5">
                        <button onClick={() => setEditingCase(study)} className="flex-1 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all">Edit</button>
                        <button 
                          onClick={() => {
                            if(confirm("Confirm deletion of this architectural asset?")) {
                              updateCaseStudies(caseStudies.filter(c => c.id !== study.id));
                            }
                          }}
                          className="px-5 py-3 bg-red-500/10 text-red-500 hover:bg-red-500/20 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CONTENT TAB */}
          {activeTab === 'content' && (
            <div className="animate-in fade-in duration-500 space-y-16">
              <div>
                <h2 className="text-3xl font-black mb-10">Site Architecture</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black uppercase text-[#ff3d00] tracking-widest px-1">Agency Brand Mark</label>
                    <input 
                      type="text" 
                      className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-black text-xl"
                      value={config.siteName}
                      onChange={(e) => updateConfig({...config, siteName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black uppercase text-[#ff3d00] tracking-widest px-1">Core Positioning Tagline</label>
                    <input 
                      type="text" 
                      className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-bold"
                      value={config.tagline}
                      onChange={(e) => updateConfig({...config, tagline: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-black mb-10 flex items-center gap-4">
                  Growth Pillars
                  <span className="text-[10px] text-white/20 uppercase font-black tracking-[0.2em] pt-1">Primary Services</span>
                </h3>
                <div className="grid grid-cols-1 gap-6">
                  {services.map((service, idx) => (
                    <div key={service.id} className="p-10 bg-white/5 border border-white/10 rounded-[3rem] flex gap-10 items-center hover:bg-white/8 transition-all group">
                      <div className="text-5xl p-6 bg-white/5 rounded-2xl border border-white/5 group-hover:border-[#ff3d00]/20 transition-all">{service.icon}</div>
                      <div className="flex-1 space-y-3">
                        <input 
                          type="text" 
                          className="bg-transparent font-black text-2xl w-full focus:text-[#ff3d00] focus:outline-none transition-colors"
                          value={service.title}
                          onChange={(e) => {
                            const updated = [...services];
                            updated[idx].title = e.target.value;
                            updateServices(updated);
                          }}
                        />
                        <input 
                          type="text" 
                          className="bg-transparent text-sm text-white/40 w-full focus:text-white/80 focus:outline-none transition-colors font-bold uppercase tracking-wider"
                          value={service.description}
                          onChange={(e) => {
                            const updated = [...services];
                            updated[idx].description = e.target.value;
                            updateServices(updated);
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CMS TAB */}
          {activeTab === 'cms' && (
            <div className="animate-in fade-in duration-500">
              <div className="flex justify-between items-center mb-12">
                <h2 className="text-3xl font-black">Knowledge OS</h2>
                <button 
                  disabled={aiGenerating}
                  onClick={handleAiBlogDraft}
                  className="px-8 py-4 bg-white text-black rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-3 transition-all disabled:opacity-50 hover:scale-105"
                >
                  {aiGenerating ? 'Processing Insights...' : '✨ Generate AI Strategy'}
                </button>
              </div>

              <div className="grid grid-cols-1 gap-8">
                {posts.map((post) => (
                  <div key={post.id} className="p-10 bg-white/5 border border-white/10 rounded-[3rem] flex flex-col md:flex-row justify-between items-center gap-10">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 text-[10px] font-black uppercase text-[#ff3d00] mb-4 tracking-widest px-1">
                        <span>{post.date}</span>
                        <span className="w-1.5 h-1.5 bg-white/10 rounded-full"></span>
                        <span>{post.author}</span>
                      </div>
                      <h4 className="font-black text-3xl mb-4">{post.title}</h4>
                      <p className="text-white/40 font-medium leading-relaxed line-clamp-2 text-lg">{post.excerpt}</p>
                    </div>
                    <div className="flex gap-4">
                      <button className="px-8 py-4 bg-white/5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-white/10 transition-all border border-white/5">Modify</button>
                      <button 
                        onClick={() => updatePosts(posts.filter(p => p.id !== post.id))}
                        className="px-8 py-4 bg-red-500/10 text-red-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-red-500/20 transition-all border border-red-500/10"
                      >
                        Purge
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SEO TAB */}
          {activeTab === 'seo' && (
            <div className="animate-in fade-in duration-500 space-y-16">
              <h2 className="text-3xl font-black mb-10">Visibility Matrix</h2>
              <div className="p-12 bg-[#ff3d00]/5 border border-[#ff3d00]/10 rounded-[3rem] mb-12 relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-10 opacity-5 group-hover:opacity-10 transition-opacity">
                    <span className="text-9xl">📈</span>
                 </div>
                 <h4 className="font-black text-2xl mb-6 text-[#ff3d00]">Global Authority Index: 92%</h4>
                 <p className="text-white/60 text-lg leading-relaxed max-w-3xl font-medium mb-8">
                   {config.siteName} is architected for algorithmic dominance. We are currently targeting: 
                   <span className="text-white block mt-4 font-black uppercase tracking-widest">Elite Video Editing, Conversion Thumbnails, Cross-Industry Web Dev.</span>
                 </p>
                 <div className="flex gap-4">
                    <span className="px-4 py-1.5 bg-white/5 rounded-full text-[10px] font-black uppercase tracking-wider">#1 Google Rank Path</span>
                    <span className="px-4 py-1.5 bg-white/5 rounded-full text-[10px] font-black uppercase tracking-wider">High Retention Content</span>
                 </div>
              </div>
              <div className="space-y-10 max-w-4xl">
                <div className="space-y-3">
                  <label className="block text-[10px] font-black uppercase text-[#ff3d00] tracking-widest px-1">Browser Page Title</label>
                  <input 
                    type="text" 
                    className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-black text-xl"
                    value={config.seoTitle}
                    onChange={(e) => updateConfig({...config, seoTitle: e.target.value})}
                  />
                </div>
                <div className="space-y-3">
                  <label className="block text-[10px] font-black uppercase text-[#ff3d00] tracking-widest px-1">Meta Content Description</label>
                  <textarea 
                    rows={4}
                    className="w-full bg-white/5 border border-white/10 p-6 rounded-[1.5rem] focus:border-[#ff3d00] outline-none transition-all font-medium leading-relaxed text-lg"
                    value={config.seoDescription}
                    onChange={(e) => updateConfig({...config, seoDescription: e.target.value})}
                  />
                </div>
                <button 
                  onClick={() => alert("Global Visibility Meta synchronized with cloud architecture.")}
                  className="w-full py-7 bg-white text-black font-black text-2xl rounded-[1.5rem] hover:scale-[1.01] transition-all shadow-2xl shadow-white/5"
                >
                  Sync Global Meta
                </button>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;
